<?php
require_once __DIR__ . '/includes/functions.php';
require_auth();

if (is_admin()) {
    redirect('admin/index.php');
}

$user = current_user();
$page_title = 'Личный кабинет — Пассажирам.РФ';
$review_errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'review') {
    $rating = (int)($_POST['rating'] ?? 5);
    $text = trim($_POST['text'] ?? '');

    if ($rating < 1 || $rating > 5) {
        $review_errors[] = 'Оценка должна быть от 1 до 5.';
    }
    if ($text === '') {
        $review_errors[] = 'Введите текст отзыва.';
    }

    if (!$review_errors) {
        db_execute("INSERT INTO reviews (user_id, rating, text) VALUES (?, ?, ?)", 'iis', [$user['id'], $rating, $text]);
        flash_set('success', 'Спасибо! Ваш отзыв добавлен.');
        redirect('profile.php#reviews');
    }
}

$applications = db_all(
    "SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC",
    'i',
    [$user['id']]
);

$reviews = db_all(
    "SELECT r.*, u.fio FROM reviews r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC LIMIT 10"
);

require_once __DIR__ . '/includes/header.php';
?>

<section class="container mt-4">
    <div class="row g-4">
        <div class="col-lg-4">
            <div class="card card-soft p-4 h-100">
                <div class="badge text-bg-primary align-self-start mb-3">Личный кабинет</div>
                <h1 class="h3">Здравствуйте,<br><?= e($user['fio']) ?></h1>
                <p class="text-secondary mb-4">Здесь можно оформить заявку, посмотреть историю и оставить отзыв об услугах.</p>
                <div class="d-grid gap-2">
                    <a href="application.php" class="btn btn-primary btn-lg">Оформить заявку</a>
                    <a href="index.php" class="btn btn-outline-primary">На главную</a>
                    <a href="logout.php" class="btn btn-outline-danger">Выход</a>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card card-soft p-4">
                <h2 class="h4 mb-3">История заявок</h2>
                <?php if ($applications): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Вид ТС</th>
                                    <th>Дата обучения</th>
                                    <th>Оплата</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($applications as $app): ?>
                                    <tr>
                                        <td><?= (int)$app['id'] ?></td>
                                        <td><?= e($app['transport']) ?></td>
                                        <td><?= date('d.m.Y', strtotime($app['study_date'])) ?></td>
                                        <td><?= e($app['payment']) ?></td>
                                        <td><span class="badge <?= status_class($app['status']) ?> status-badge"><?= e($app['status']) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-box">
                        <h3 class="h5">Заявок пока нет</h3>
                        <p class="text-secondary mb-3">Оформите первую заявку на обучение.</p>
                        <a href="application.php" class="btn btn-primary">Подать заявку</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="container mt-4" id="reviews">
    <div class="row g-4">
        <div class="col-lg-5">
            <div class="card card-soft p-4">
                <h2 class="h4 mb-3">Оставить отзыв</h2>
                <?php if ($review_errors): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($review_errors as $error): ?>
                                <li><?= e($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="post" class="row g-3">
                    <input type="hidden" name="action" value="review">
                    <div class="col-12">
                        <label class="form-label">Оценка</label>
                        <select name="rating" class="form-select" required>
                            <option value="5">5 — отлично</option>
                            <option value="4">4 — хорошо</option>
                            <option value="3">3 — нормально</option>
                            <option value="2">2 — плохо</option>
                            <option value="1">1 — очень плохо</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Текст отзыва</label>
                        <textarea name="text" class="form-control" rows="5" placeholder="Напишите отзыв об услугах портала" required></textarea>
                    </div>
                    <div class="col-12 d-grid">
                        <button type="submit" class="btn btn-primary">Опубликовать отзыв</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card card-soft p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2 class="h4 mb-0">Отзывы об услугах</h2>
                    <a href="reviews.php" class="btn btn-outline-primary btn-sm">Все отзывы</a>
                </div>
                <?php if ($reviews): ?>
                    <div class="vstack gap-3">
                        <?php foreach ($reviews as $review): ?>
                            <div class="border rounded-4 p-3 bg-white">
                                <div class="d-flex justify-content-between gap-2 flex-wrap">
                                    <strong><?= e($review['fio']) ?></strong>
                                    <span class="text-warning"><?= e(rating_stars($review['rating'])) ?></span>
                                </div>
                                <div class="review-text mt-2"><?= e($review['text']) ?></div>
                                <div class="text-secondary small mt-2"><?= date('d.m.Y H:i', strtotime($review['created_at'])) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-box">Пока отзывов нет.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
