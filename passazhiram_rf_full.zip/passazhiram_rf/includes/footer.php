</main>
<footer class="footer mt-5 py-4 bg-dark text-white">
    <div class="container d-flex flex-column flex-md-row justify-content-between gap-2">
        <div>
            <strong>Пассажирам.РФ</strong><br>
            <span class="text-white-50">Портал записи на обучение водителей общественного транспорта</span>
        </div>
        <div class="text-white-50">
            Автобус · Электробус · Трамвай
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
