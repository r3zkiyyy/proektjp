<?php
$title = $page_title ?? 'Пассажирам.РФ';
$base = APP_ROOT;
$user = current_user();
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= $base ?>assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $base ?>index.php">Пассажирам.РФ</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item"><a class="nav-link" href="<?= $base ?>index.php">Главная</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= $base ?>reviews.php">Отзывы</a></li>

                <?php if (is_auth()): ?>
                    <?php if (is_admin()): ?>
                        <li class="nav-item"><a class="nav-link" href="<?= $base ?>admin/index.php">Админ-панель</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?= $base ?>admin/users.php">Пользователи</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?= $base ?>profile.php">Личный кабинет</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?= $base ?>application.php">Оформить заявку</a></li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <span class="nav-link small opacity-75"><?= e($user['login'] ?? '') ?></span>
                    </li>
                    <li class="nav-item"><a class="btn btn-light btn-sm" href="<?= $base ?>logout.php">Выход</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= $base ?>login.php">Вход</a></li>
                    <li class="nav-item"><a class="btn btn-light btn-sm" href="<?= $base ?>register.php">Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main>
<?php $flash = flash_get(); ?>
<?php if ($flash): ?>
    <div class="container mt-4">
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
<?php endif; ?>
