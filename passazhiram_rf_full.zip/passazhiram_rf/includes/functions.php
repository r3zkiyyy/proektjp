<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

if (!defined('APP_ROOT')) {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    define('APP_ROOT', strpos($script, '/admin/') !== false ? '../' : '');
}

function e($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function db_execute($sql, $types = '', $params = []) {
    global $conn;
    $stmt = mysqli_prepare($conn, $sql);

    if ($types !== '' && !empty($params)) {
        $refs = [];
        foreach ($params as $key => $value) {
            $refs[$key] = &$params[$key];
        }
        mysqli_stmt_bind_param($stmt, $types, ...$refs);
    }

    mysqli_stmt_execute($stmt);
    return $stmt;
}

function db_all($sql, $types = '', $params = []) {
    $stmt = db_execute($sql, $types, $params);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function db_one($sql, $types = '', $params = []) {
    $rows = db_all($sql, $types, $params);
    return $rows[0] ?? null;
}

function is_auth() {
    return isset($_SESSION['user']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_admin() {
    return is_auth() && ($_SESSION['user']['role'] ?? '') === 'admin';
}

function require_auth() {
    if (!is_auth()) {
        redirect(APP_ROOT . 'login.php');
    }
}

function require_admin() {
    require_auth();
    if (!is_admin()) {
        redirect(APP_ROOT . 'profile.php');
    }
}

function flash_set($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flash_get() {
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function status_class($status) {
    switch ($status) {
        case 'Новая':
            return 'text-bg-warning';
        case 'Идет обучение':
            return 'text-bg-primary';
        case 'Обучение завершено':
            return 'text-bg-success';
        default:
            return 'text-bg-secondary';
    }
}

function rating_stars($rating) {
    $rating = (int)$rating;
    $rating = max(1, min(5, $rating));
    return str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
}
?>
