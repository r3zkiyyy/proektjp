<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$page_title = 'Пользователи — Пассажирам.РФ';
$q = trim($_GET['q'] ?? '');

$sql = "SELECT u.*, COUNT(a.id) AS applications_count
        FROM users u
        LEFT JOIN applications a ON a.user_id = u.id";
$types = '';
$params = [];
if ($q !== '') {
    $sql .= " WHERE u.fio LIKE ? OR u.login LIKE ? OR u.phone LIKE ? OR u.email LIKE ?";
    $like = '%' . $q . '%';
    $types = 'ssss';
    $params = [$like, $like, $like, $like];
}
$sql .= " GROUP BY u.id ORDER BY u.created_at DESC";
$users = db_all($sql, $types, $params);

require_once __DIR__ . '/../includes/header.php';
?>

<section class="container mt-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h2 mb-1">Пользователи</h1>
            <p class="text-secondary mb-0">Просмотр зарегистрированных пользователей портала.</p>
        </div>
        <a href="index.php" class="btn btn-outline-primary">К заявкам</a>
    </div>

    <div class="card card-soft p-4 mb-4">
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-9">
                <label class="form-label">Поиск</label>
                <input type="text" name="q" class="form-control" value="<?= e($q) ?>" placeholder="ФИО, логин, телефон, email">
            </div>
            <div class="col-md-3 d-grid">
                <button type="submit" class="btn btn-primary">Найти</button>
            </div>
        </form>
    </div>

    <div class="card card-soft p-4">
        <?php if ($users): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Логин</th>
                            <th>ФИО</th>
                            <th>Контакты</th>
                            <th>Роль</th>
                            <th>Заявок</th>
                            <th>Дата регистрации</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?= (int)$u['id'] ?></td>
                                <td><?= e($u['login']) ?></td>
                                <td><?= e($u['fio']) ?></td>
                                <td class="small"><?= e($u['phone']) ?><br><?= e($u['email']) ?></td>
                                <td><span class="badge <?= $u['role'] === 'admin' ? 'text-bg-dark' : 'text-bg-secondary' ?>"><?= e($u['role']) ?></span></td>
                                <td><?= (int)$u['applications_count'] ?></td>
                                <td><?= date('d.m.Y H:i', strtotime($u['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-box">Пользователи не найдены.</div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
