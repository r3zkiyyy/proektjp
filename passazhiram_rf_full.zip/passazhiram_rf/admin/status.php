<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$allowed_statuses = ['Новая', 'Идет обучение', 'Обучение завершено'];
$id = (int)($_POST['id'] ?? 0);
$status = trim($_POST['status'] ?? '');

if ($id <= 0 || !in_array($status, $allowed_statuses, true)) {
    flash_set('danger', 'Не удалось изменить статус заявки.');
    redirect('index.php');
}

db_execute("UPDATE applications SET status = ? WHERE id = ?", 'si', [$status, $id]);
flash_set('success', 'Статус заявки успешно изменён.');
redirect('index.php');
?>
