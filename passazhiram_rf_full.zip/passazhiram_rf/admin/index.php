<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$page_title = 'Админ-панель — Пассажирам.РФ';
$q = trim($_GET['q'] ?? '');
$status = trim($_GET['status'] ?? '');
$allowed_statuses = ['Новая', 'Идет обучение', 'Обучение завершено'];

$where = [];
$types = '';
$params = [];

if ($q !== '') {
    $where[] = "(u.fio LIKE ? OR u.login LIKE ? OR u.phone LIKE ? OR u.email LIKE ?)";
    $like = '%' . $q . '%';
    $types .= 'ssss';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if ($status !== '' && in_array($status, $allowed_statuses, true)) {
    $where[] = "a.status = ?";
    $types .= 's';
    $params[] = $status;
}

$sql = "SELECT a.*, u.fio, u.login, u.phone, u.email
        FROM applications a
        JOIN users u ON a.user_id = u.id";
if ($where) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY a.created_at DESC";

$applications = db_all($sql, $types, $params);

$total = db_one("SELECT COUNT(*) AS cnt FROM applications")['cnt'] ?? 0;
$new_count = db_one("SELECT COUNT(*) AS cnt FROM applications WHERE status = 'Новая'")['cnt'] ?? 0;
$process_count = db_one("SELECT COUNT(*) AS cnt FROM applications WHERE status = 'Идет обучение'")['cnt'] ?? 0;
$done_count = db_one("SELECT COUNT(*) AS cnt FROM applications WHERE status = 'Обучение завершено'")['cnt'] ?? 0;

require_once __DIR__ . '/../includes/header.php';
?>

<section class="container mt-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h2 mb-1">Админ-панель</h1>
            <p class="text-secondary mb-0">Полный доступ к просмотру заявок и изменению статусов.</p>
        </div>
        <a href="../index.php" class="btn btn-outline-primary">На главную</a>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3"><div class="card card-soft p-3"><div class="text-secondary">Всего</div><div class="h3 mb-0"><?= (int)$total ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="card card-soft p-3"><div class="text-secondary">Новые</div><div class="h3 mb-0 text-warning"><?= (int)$new_count ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="card card-soft p-3"><div class="text-secondary">Идет обучение</div><div class="h3 mb-0 text-primary"><?= (int)$process_count ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="card card-soft p-3"><div class="text-secondary">Завершено</div><div class="h3 mb-0 text-success"><?= (int)$done_count ?></div></div></div>
    </div>

    <div class="card card-soft p-4 mb-4">
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-6">
                <label class="form-label">Поиск по ФИО, логину, телефону или email</label>
                <input type="text" name="q" class="form-control" value="<?= e($q) ?>" placeholder="Например: Иванов">
            </div>
            <div class="col-md-3">
                <label class="form-label">Статус</label>
                <select name="status" class="form-select">
                    <option value="">Все статусы</option>
                    <?php foreach ($allowed_statuses as $st): ?>
                        <option value="<?= e($st) ?>" <?= $status === $st ? 'selected' : '' ?>><?= e($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary" type="submit">Показать</button>
            </div>
        </form>
    </div>

    <div class="card card-soft p-4">
        <h2 class="h4 mb-3">Все заявки</h2>
        <?php if ($applications): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>№</th>
                            <th>Пользователь</th>
                            <th>Контакты</th>
                            <th>Вид ТС</th>
                            <th>Дата обучения</th>
                            <th>Оплата</th>
                            <th>Статус</th>
                            <th>Действие</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><?= (int)$app['id'] ?></td>
                                <td>
                                    <strong><?= e($app['fio']) ?></strong><br>
                                    <span class="text-secondary small">Логин: <?= e($app['login']) ?></span>
                                </td>
                                <td class="small">
                                    <?= e($app['phone']) ?><br>
                                    <?= e($app['email']) ?>
                                </td>
                                <td><?= e($app['transport']) ?></td>
                                <td><?= date('d.m.Y', strtotime($app['study_date'])) ?></td>
                                <td><?= e($app['payment']) ?></td>
                                <td><span class="badge <?= status_class($app['status']) ?> status-badge"><?= e($app['status']) ?></span></td>
                                <td style="min-width: 210px;">
                                    <form action="status.php" method="post" class="d-flex gap-2">
                                        <input type="hidden" name="id" value="<?= (int)$app['id'] ?>">
                                        <select name="status" class="form-select form-select-sm">
                                            <?php foreach ($allowed_statuses as $st): ?>
                                                <option value="<?= e($st) ?>" <?= $app['status'] === $st ? 'selected' : '' ?>><?= e($st) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button class="btn btn-primary btn-sm" type="submit">OK</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-box">Заявки не найдены.</div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
