<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Отзывы — Пассажирам.РФ';
$reviews = db_all("SELECT r.*, u.fio FROM reviews r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
require_once __DIR__ . '/includes/header.php';
?>

<section class="container mt-4">
    <div class="card card-soft p-4 p-md-5 mb-4">
        <h1 class="h2">Отзывы об услугах</h1>
        <p class="text-secondary mb-0">Здесь отображаются отзывы пользователей портала «Пассажирам.РФ».</p>
    </div>

    <?php if ($reviews): ?>
        <div class="row g-4">
            <?php foreach ($reviews as $review): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card card-soft h-100 p-4">
                        <div class="d-flex justify-content-between gap-2 align-items-start">
                            <strong><?= e($review['fio']) ?></strong>
                            <span class="text-warning"><?= e(rating_stars($review['rating'])) ?></span>
                        </div>
                        <p class="review-text mt-3 mb-3"><?= e($review['text']) ?></p>
                        <div class="text-secondary small mt-auto"><?= date('d.m.Y H:i', strtotime($review['created_at'])) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-box">Пока отзывов нет.</div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
