<?php
require_once __DIR__ . '/includes/functions.php';

if (is_auth()) {
    redirect(is_admin() ? 'admin/index.php' : 'profile.php');
}

$page_title = 'Регистрация — Пассажирам.РФ';
$errors = [];
$old = [
    'login' => '',
    'fio' => '',
    'birth_date' => '',
    'phone' => '',
    'email' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['login'] = trim($_POST['login'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $password_repeat = trim($_POST['password_repeat'] ?? '');
    $old['fio'] = trim($_POST['fio'] ?? '');
    $old['birth_date'] = trim($_POST['birth_date'] ?? '');
    $old['phone'] = trim($_POST['phone'] ?? '');
    $old['email'] = trim($_POST['email'] ?? '');

    if (!preg_match('/^[A-Za-z0-9]{6,}$/', $old['login'])) {
        $errors[] = 'Логин должен быть минимум 6 символов и состоять из латинских букв и цифр.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Пароль должен быть минимум 8 символов.';
    }
    if ($password !== $password_repeat) {
        $errors[] = 'Пароли не совпадают.';
    }
    if ($old['fio'] === '') {
        $errors[] = 'Введите ФИО.';
    }
    if ($old['birth_date'] === '') {
        $errors[] = 'Укажите дату рождения.';
    }
    if ($old['phone'] === '') {
        $errors[] = 'Введите телефон.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Введите корректный email.';
    }

    $exists = db_one("SELECT id FROM users WHERE login = ?", 's', [$old['login']]);
    if ($exists) {
        $errors[] = 'Пользователь с таким логином уже существует.';
    }

    if (!$errors) {
        db_execute(
            "INSERT INTO users (login, password, fio, birth_date, phone, email, role) VALUES (?, ?, ?, ?, ?, ?, 'user')",
            'ssssss',
            [$old['login'], $password, $old['fio'], $old['birth_date'], $old['phone'], $old['email']]
        );
        flash_set('success', 'Регистрация прошла успешно. Теперь войдите в личный кабинет.');
        redirect('login.php');
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container">
    <div class="card card-soft auth-card p-4 p-md-5">
        <h1 class="h3 mb-2 text-center">Регистрация</h1>
        <p class="text-secondary text-center mb-4">Создайте аккаунт для подачи заявки на обучение.</p>

        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" class="row g-3">
            <div class="col-12">
                <label class="form-label">Логин</label>
                <input type="text" name="login" class="form-control" value="<?= e($old['login']) ?>" required>
                <div class="form-text">Минимум 6 символов, латиница и цифры.</div>
            </div>
            <div class="col-md-6">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Повтор пароля</label>
                <input type="password" name="password_repeat" class="form-control" required>
            </div>
            <div class="col-12">
                <label class="form-label">ФИО</label>
                <input type="text" name="fio" class="form-control" value="<?= e($old['fio']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Дата рождения</label>
                <input type="date" name="birth_date" class="form-control" value="<?= e($old['birth_date']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Телефон</label>
                <input type="text" name="phone" class="form-control" value="<?= e($old['phone']) ?>" placeholder="+7 (999) 000-00-00" required>
            </div>
            <div class="col-12">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= e($old['email']) ?>" required>
            </div>
            <div class="col-12 d-grid">
                <button class="btn btn-primary btn-lg" type="submit">Зарегистрироваться</button>
            </div>
        </form>
        <div class="text-center mt-3">
            <a href="login.php">Уже есть аккаунт? Войти</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
