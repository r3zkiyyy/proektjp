<?php
require_once __DIR__ . '/includes/functions.php';
require_auth();

if (is_admin()) {
    redirect('admin/index.php');
}

$user = current_user();
$page_title = 'Оформление заявки — Пассажирам.РФ';
$errors = [];
$old = [
    'transport' => 'Автобус',
    'study_date' => date('Y-m-d', strtotime('+1 day')),
    'payment' => 'Банковская карта'
];

$transports = ['Автобус', 'Электробус', 'Трамвай'];
$payments = ['Банковская карта', 'Наличные', 'СБП'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['transport'] = trim($_POST['transport'] ?? '');
    $old['study_date'] = trim($_POST['study_date'] ?? '');
    $old['payment'] = trim($_POST['payment'] ?? '');

    if (!in_array($old['transport'], $transports, true)) {
        $errors[] = 'Выберите корректный вид транспортного средства.';
    }
    if ($old['study_date'] === '') {
        $errors[] = 'Укажите удобную дату начала обучения.';
    } elseif ($old['study_date'] < date('Y-m-d')) {
        $errors[] = 'Дата обучения не может быть раньше сегодняшнего дня.';
    }
    if (!in_array($old['payment'], $payments, true)) {
        $errors[] = 'Выберите корректный способ оплаты.';
    }

    if (!$errors) {
        db_execute(
            "INSERT INTO applications (user_id, transport, study_date, payment, status) VALUES (?, ?, ?, ?, 'Новая')",
            'isss',
            [$user['id'], $old['transport'], $old['study_date'], $old['payment']]
        );
        flash_set('success', 'Заявка отправлена администратору. Статус заявки: Новая.');
        redirect('profile.php');
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<section class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card card-soft p-4 p-md-5">
                <div class="badge text-bg-primary align-self-start mb-3">Оформление заявки</div>
                <h1 class="h2">Запись на обучение</h1>
                <p class="text-secondary mb-4">
                    Выберите вид транспортного средства, удобную дату начала обучения и способ оплаты.
                    После отправки заявка попадёт администратору на рассмотрение.
                </p>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?= e($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Вид транспортного средства</label>
                        <select name="transport" class="form-select form-select-lg" required>
                            <?php foreach ($transports as $transport): ?>
                                <option value="<?= e($transport) ?>" <?= $old['transport'] === $transport ? 'selected' : '' ?>><?= e($transport) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Удобная дата начала обучения</label>
                        <input type="date" name="study_date" class="form-control form-control-lg" value="<?= e($old['study_date']) ?>" min="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-semibold">Способ оплаты</label>
                        <div class="row g-3">
                            <?php foreach ($payments as $payment): ?>
                                <div class="col-md-4">
                                    <input class="btn-check" type="radio" name="payment" id="payment_<?= md5($payment) ?>" value="<?= e($payment) ?>" <?= $old['payment'] === $payment ? 'checked' : '' ?>>
                                    <label class="btn btn-outline-primary w-100 py-3" for="payment_<?= md5($payment) ?>"><?= e($payment) ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="col-12 d-flex flex-column flex-sm-row gap-2">
                        <button type="submit" class="btn btn-primary btn-lg px-5">Отправить заявку</button>
                        <a href="profile.php" class="btn btn-outline-secondary btn-lg">Назад в ЛК</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
