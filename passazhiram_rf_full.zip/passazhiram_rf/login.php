<?php
require_once __DIR__ . '/includes/functions.php';

if (is_auth()) {
    redirect(is_admin() ? 'admin/index.php' : 'profile.php');
}

$page_title = 'Вход — Пассажирам.РФ';
$error = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $user = db_one("SELECT * FROM users WHERE login = ? AND password = ?", 'ss', [$login, $password]);

    if ($user) {
        $_SESSION['user'] = $user;
        flash_set('success', 'Вы успешно вошли в систему.');
        redirect($user['role'] === 'admin' ? 'admin/index.php' : 'profile.php');
    } else {
        $error = 'Неверный логин или пароль.';
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container">
    <div class="card card-soft auth-card p-4 p-md-5">
        <h1 class="h3 mb-2 text-center">Вход</h1>
        <p class="text-secondary text-center mb-4">Войдите в личный кабинет или админ-панель.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" class="row g-3">
            <div class="col-12">
                <label class="form-label">Логин</label>
                <input type="text" name="login" class="form-control" value="<?= e($login) ?>" required>
            </div>
            <div class="col-12">
                <label class="form-label">Пароль</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="col-12 d-grid">
                <button class="btn btn-primary btn-lg" type="submit">Войти</button>
            </div>
        </form>

        <div class="alert alert-info mt-4 mb-0 small">
            <strong>Администратор:</strong> Admin26 / Demo26<br>
            <strong>Тестовый пользователь:</strong> User26 / DemoUser26
        </div>

        <div class="text-center mt-3">
            <a href="register.php">Нет аккаунта? Зарегистрироваться</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
