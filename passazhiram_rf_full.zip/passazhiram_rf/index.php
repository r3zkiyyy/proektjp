<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Пассажирам.РФ — обучение водителей';
$reviews = db_all("SELECT r.*, u.fio FROM reviews r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC LIMIT 3");
require_once __DIR__ . '/includes/header.php';
?>

<section class="container mt-4">
    <div class="hero">
        <div class="position-relative" style="z-index: 2;">
            <span class="badge text-bg-primary mb-3">Демо-портал</span>
            <h1>Запись на обучение водителей общественного транспорта</h1>
            <p class="mt-3">
                Портал «Пассажирам.РФ» помогает оформить заявку на курсы водителей автобуса,
                электробуса или трамвая и отслеживать статус обучения в личном кабинете.
            </p>
            <div class="d-flex flex-column flex-sm-row gap-2 mt-4">
                <?php if (is_auth() && !is_admin()): ?>
                    <a class="btn btn-primary btn-lg px-4" href="application.php">Оформить заявку</a>
                    <a class="btn btn-outline-primary btn-lg px-4" href="profile.php">Личный кабинет</a>
                <?php elseif (is_admin()): ?>
                    <a class="btn btn-primary btn-lg px-4" href="admin/index.php">Открыть админ-панель</a>
                <?php else: ?>
                    <a class="btn btn-primary btn-lg px-4" href="register.php">Начать обучение</a>
                    <a class="btn btn-outline-primary btn-lg px-4" href="login.php">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="container mt-5">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card card-soft h-100 p-4">
                <div class="feature-icon">🚌</div>
                <h4>Выбор транспорта</h4>
                <p class="text-secondary mb-0">Автобус, электробус или трамвай — выберите направление обучения.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-soft h-100 p-4">
                <div class="feature-icon">📅</div>
                <h4>Удобная дата</h4>
                <p class="text-secondary mb-0">Укажите дату начала обучения прямо при оформлении заявки.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-soft h-100 p-4">
                <div class="feature-icon">✅</div>
                <h4>Контроль статуса</h4>
                <p class="text-secondary mb-0">Следите за статусом заявки: новая, идет обучение или завершено.</p>
            </div>
        </div>
    </div>
</section>

<section class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Отзывы пользователей</h2>
        <a href="reviews.php" class="btn btn-outline-primary btn-sm">Все отзывы</a>
    </div>
    <div class="row g-4">
        <?php if ($reviews): ?>
            <?php foreach ($reviews as $review): ?>
                <div class="col-md-4">
                    <div class="card card-soft h-100 p-4">
                        <div class="text-warning fs-5"><?= e(rating_stars($review['rating'])) ?></div>
                        <p class="review-text mt-2 mb-3"><?= e($review['text']) ?></p>
                        <div class="text-secondary small">— <?= e($review['fio']) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12"><div class="empty-box">Пока отзывов нет.</div></div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
