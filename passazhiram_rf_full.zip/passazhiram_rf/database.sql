CREATE DATABASE IF NOT EXISTS `passazhiram` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `passazhiram`;

DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `applications`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `login` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(50) NOT NULL,
  `fio` VARCHAR(255) NOT NULL,
  `birth_date` DATE DEFAULT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `email` VARCHAR(120) DEFAULT NULL,
  `role` ENUM('user','admin') NOT NULL DEFAULT 'user',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `applications` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `transport` ENUM('Автобус','Электробус','Трамвай') NOT NULL,
  `study_date` DATE NOT NULL,
  `payment` ENUM('Наличные','Банковская карта','СБП') NOT NULL,
  `status` ENUM('Новая','Идет обучение','Обучение завершено') NOT NULL DEFAULT 'Новая',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_applications_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `reviews` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `rating` TINYINT NOT NULL DEFAULT 5,
  `text` TEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`login`, `password`, `fio`, `birth_date`, `phone`, `email`, `role`) VALUES
('Admin26', 'Demo26', 'Администратор портала', NULL, '+7 (900) 000-00-00', 'admin@passazhiram.rf', 'admin'),
('User26', 'DemoUser26', 'Иванов Иван Иванович', '2000-01-15', '+7 (999) 111-22-33', 'user@example.ru', 'user');

INSERT INTO `applications` (`user_id`, `transport`, `study_date`, `payment`, `status`) VALUES
(2, 'Автобус', DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Банковская карта', 'Новая'),
(2, 'Трамвай', DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'СБП', 'Идет обучение');

INSERT INTO `reviews` (`user_id`, `rating`, `text`) VALUES
(2, 5, 'Удобный портал, заявку получилось оформить быстро.');
