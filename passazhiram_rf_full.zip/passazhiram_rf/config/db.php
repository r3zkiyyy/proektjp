<?php
// Настройки подключения для Open Server Panel
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'passazhiram';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    mysqli_set_charset($conn, 'utf8mb4');
} catch (Throwable $e) {
    die('Ошибка подключения к базе данных. Проверьте config/db.php и импорт database.sql');
}
?>
